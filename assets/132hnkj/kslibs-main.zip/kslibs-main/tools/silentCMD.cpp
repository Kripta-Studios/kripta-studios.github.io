#include <cstdlib>
#include <iostream>

int main(int argc,const char* argv[])
{
	if (argc == 1) return 0;
	system(argv[1]);

}
